package com.reply.eis.persistence.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

//	Connection connection = null;
//	
//	try {
//		Class.forName("oracle.jdbc.driver.OracleDriver");
//		connection = DriverManager.getConnection(
//				"jdbc:oracle:thin:@localhost:1521:orcl", "editoriale",
//				"editoriale");
//	} catch (ClassNotFoundException exc) {
//		exc.printStackTrace();
//	} catch (SQLException exc) {
//		exc.printStackTrace();
//	}
//	return connection;
}
