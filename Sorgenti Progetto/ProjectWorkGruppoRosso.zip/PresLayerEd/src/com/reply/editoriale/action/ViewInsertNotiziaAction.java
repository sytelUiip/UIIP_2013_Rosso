package com.reply.editoriale.action;

import com.opensymphony.xwork2.ActionSupport;

public class ViewInsertNotiziaAction extends ActionSupport {
	
	public String execute(){
		
		return "success";
	}

}
