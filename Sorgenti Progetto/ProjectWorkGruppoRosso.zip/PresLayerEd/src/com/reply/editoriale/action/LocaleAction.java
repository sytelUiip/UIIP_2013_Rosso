package com.reply.editoriale.action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;


	public class LocaleAction extends ActionSupport{
		 
		//business logic
		public String execute() {
			
//		
			
//				Map utente_session = ActionContext.getContext().getSession();	
//				utente_session.put("lingua", "en");
			
			return "success";
	
		
	}
	}

